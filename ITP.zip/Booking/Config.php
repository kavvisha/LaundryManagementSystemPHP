<?php

define("DBHOST", "127.0.0.1");
define("DB","room-booking");
define("DBUSER", "root");
define("DBPASS", " ");

?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="refresh" content="0;url=pages/index.html">
<title>SB Admin 2</title>
<script language="javascript">
    window.location.href = "pages/index.html"
</script>
</head>
<body>
Go to <a href="pages/index.html">/pages/index.html</a>
</body>
</html>

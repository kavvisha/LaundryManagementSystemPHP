<?php

//database configuration file


define("DBHOST", "localhost");
define("DB","hotel");
define("DBUSER", "root");
define("DBPASS", "123");

?>

<?php include '../inc/header.php'; ?>
    <body>
        <header class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <h2 class="page-header">View Item Batch</h2>
                    </div>
                </div>
            
                <div class="container">
                <div class="row">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            View Entries
                        </div>
                        <div class="panel-body">
                            
                        </div>
                    </div>
                </div>
        </header>
    </body>
</html>

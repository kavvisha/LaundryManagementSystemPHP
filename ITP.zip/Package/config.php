<?php

define("DBHOST", "localhost");
define("DB","hotelmanagement");
define("DBUSER", "root");
define("DBPASS", "abc123");

?>

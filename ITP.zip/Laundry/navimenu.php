
<?php include '../inc/header.php'; ?>

<body>

<div class="container">
  <h2>Vertical Button Group</h2>
  <p>Use the .btn-group-vertical class to create a vertical button group:</p>
  <div class="btn-group-vertical">
   
    <div class="row">
    	<div class="col-lg-12">
    		<div class="row">
                        <div class="col-sm-3">
                            <button type="button" class="jumbotron btn-primary"><i class="fa fa-bolt" aria-hidden="true" fa-5x></i></span></button>
                	</div>
                        <div class="col-sm-3"></div>
			<div class="col-sm-3">
                            <button type="button" class="jumbotron btn-primary"><span class="glyphicon glyphicon-align-left" aria-hidden="true"></span></button>
                	</div>
   
   
   				</div>
        	</div>
     </div> 
     
     
     
     
    <button type="button" class="btn btn-primary">Samsung</button>
    <button type="button" class="btn btn-primary">Sony</button>
  </div>
</div>

</body>

<?php include '../inc/footer.php'; ?>
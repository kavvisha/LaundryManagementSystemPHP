<?php

//echo"<br>";
//echo"<div class='col-lg-3 col-md-4'> <div class='panel panel-blue'> <div class='panel-heading'> <div class='row'><div class='col-xs-12 text-center'><div class='alert alert-info >";
//echo"      <button type='button' class='btn btn-default btn-lg'></button><a href='./viewJobs.php' class='alert-link'>View ongoing Jobs</a>";
//echo"</div></div></div></div></div></div>";

//echo"<div class='col-lg-3 col-md-4'> <div class='panel panel-blue'> <div class='panel-heading'> <div class='row'><div class='col-xs-12 text-center'><div class='alert alert-info >";
//echo"      <button type='button' class='btn btn-default btn-lg'></button><a href='AddJob.php' class='alert-link'>Add Job</a>";
//echo"</div></div></div></div></div></div>";

//echo"<div class='col-lg-3 col-md-4'> <div class='panel panel-blue'> <div class='panel-heading'> <div class='row'><div class='col-xs-12 text-center'><div class='alert alert-info >";
//echo"      <button type='button' class='btn btn-default btn-lg'></button><a href='veiwJobs.php' class='alert-link'>Worker History</a>";
//echo"</div></div></div></div></div></div>";

//echo"<div class='col-lg-3 col-md-4'> <div class='panel panel-blue'> <div class='panel-heading'> <div class='row'><div class='col-xs-12 text-center'><div class='alert alert-info >";
//echo"      <button type='button' class='btn btn-default btn-lg'><a href='veiwJobs.php' class='alert-link'>Stock Management</a></button>";
//echo"</div></div></div></div></div></div>";
//echo"<br>";
//echo"      <button type='button' class='btn btn-primary btn-lg'><a href='AddJob.php'  style=' text-decoration: none; color: #FFF ; font-size : 16px ;' >Add Job</a></button>";
//echo"      <button type='button' class='btn btn-primary btn-lg'><a href='viewJobs.php' class='alert-link' style=' text-decoration: none; color: #FFF ;font-size : 16px ;' >Veiw Ongoing Jobs</a></button>";
//echo"      <button type='button' class='btn btn-primary btn-lg'><a href='JobHistory.php' class='alert-link' style=' text-decoration: none; color: #FFF ;font-size : 16px ;' >Job History</a></button>";
//echo"      <button type='button' class='btn btn-primary btn-lg'><a href='veiwJobs.php' class='alert-link' style=' text-decoration: none; color: #FFF ;font-size : 16px ;' >Stock Management</a></button>";

echo"<br></br>";
echo " <nav class='navbar navbar-default'>";
    echo"<div class='container-fuild'>";
    echo"<ul class='nav navbar-nav'>";
        echo"<li> <a href='AddJob.php'>Add Job</a></li>";
        echo"<li> <a href='viewJobs.php'>Veiw Ongoing jobs</a></li>";
        echo"<li> <a href='JobHistory.php'>Job History</a></li>";
        echo"<li> <a href='laundryStock.php'>Stock Management</a></li>";
        echo"<li> <a href='laundryMachines.php'>Laundry Machines</a></li>";
    echo"</ul>";
echo"</div>";
echo"</nav>";









?>
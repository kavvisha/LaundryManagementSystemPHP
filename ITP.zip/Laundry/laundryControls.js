    var mainApp = angular.module("mainApp",[]);
        mainApp.controller('lCtrl',function($scope){
            $scope.bookID="";
            $scope.roomID="";
            $scope.workerName="";
            
        });
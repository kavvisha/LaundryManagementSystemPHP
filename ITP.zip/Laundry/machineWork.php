<?php
require_once '../inc/conn.php';
$machineNo=$_GET['machineNo'];
    echo $machineNo;

    $sql="UPDATE laundryMachines SET working=1 WHERE machineNo=".$machineNo."";
    $stmt=$conn->prepare($sql);
    
    if($stmt->execute()){
        echo"updated";
        header('Location:laundryMachines.php');
        
        
    }
    

<?php

class User{
    
     public function checkUsername($uname){
        
        
        
    }
    
    public function addUser(){
        
        
        
    }
    
    
    public function login($uname, $pass){
        
        
    }
    
}

?>


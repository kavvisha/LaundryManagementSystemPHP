<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Hotel Management System</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css " rel="stylesheet">

    

    <!-- Custom CSS -->
    <link href="css/sb-admin-2.css" rel="stylesheet">

    

    <!-- Custom Fonts -->
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">

  
</head>
<body>
<div class="row">
    <div class="container">
        <div class="col-lg-12">
<form>
    <h1>Allocated Spent Comparison</h1>
    <label>Department Name</label>
    <select class="form-control">
        <option value="sd">Select Department</option>
        <option value="in">Inventory</option>
        <option value="Em">Employee Manegement</option>
        <option value="ln">Laundry</option>
        <option value="kt">Kitchen</option>
    </select><br><br>
    <label>Total Cost Of Money For Month</label>
    <input class="form-control" type="txt" name="tc" required><br><br>
    <label>Total Money Allocation Within the Month</label>
    <input class="form-control" type="text" name="tm"requred><br><br>
    <label>Comparison</label>
    <input class="form-control" type="text" name="cm" required ><br><br>
    <button class="btn btn-success" type="reset">Clear Entries</button>
</form>
        </div>
        </div>
        </div>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin 2 - Bootstrap Admin Theme</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css " rel="stylesheet">

    

    <!-- Custom CSS -->
    <link href="css/sb-admin-2.css" rel="stylesheet">

    

    <!-- Custom Fonts -->
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">

  
</head>
<body>

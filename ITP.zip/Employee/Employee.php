<?php

/**
 * Description of Employee
 *
 * @author Theekshana
 */
class Employee {

//    private $EmpID;
//    private $fullname;
//    private $NIC;
//    private $MNum;
//    private $LNum;
//    private $addr;
//    private $ContDu;
//    private $BasicSal;
//    private $Post;
//    private $AddDate;
//    private $PhotoFile;

//    public function __construct($eid) {
//        $this->EmpID=$eid;
//    }
    
    public function add(){
        
        
    }

}
